package com.example.mytab;


import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class PersonList extends Activity {

	PersonDatabase db;
	ArrayList<Person> list = new ArrayList<Person>();
	ListView lv;
	TextView tv;
	ItemAdapter adapter;
	AdapterView.AdapterContextMenuInfo info;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.namelist);
		
		db = new PersonDatabase(this);
		if(db.getCount()>0){
			list = db.getAllPerson();
		}
		
		this.lv = (ListView) this.findViewById(R.id.listView1);
		this.adapter = new ItemAdapter(this,list);
		this.lv.setAdapter(adapter);
		adapter.notifyDataSetChanged();
		this.registerForContextMenu(lv);
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		
		int i = item.getItemId();
		switch(i){
		case R.id.delete:
			String name = list.get(info.position).getName();
			db.deleteDB(name);
			list.remove(info.position);
			Toast.makeText(this, "Deleted!",Toast.LENGTH_SHORT).show();
			adapter.notifyDataSetChanged();
			
		
		}
		
		return super.onContextItemSelected(item);
	}
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		super.onCreateContextMenu(menu, v, menuInfo);
		this.getMenuInflater().inflate(R.menu.contextmenu, menu);
		info = (AdapterContextMenuInfo) menuInfo;
		menu.setHeaderTitle(list.get(info.position).getName());
		
	}

	
	
	
	
}
