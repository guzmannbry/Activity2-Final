package com.example.mylatlng_prefinal;

import java.util.ArrayList;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class List extends Activity implements OnClickListener{
	LocationAdapter adapter;
	ListView lv;
	public static ArrayList<Location> source = new ArrayList<Location>();
	AdapterView.AdapterContextMenuInfo info;
	EditText txtSearch;
	TextView empty;
	LocationDatabase db;
	AlertDialog g;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list);
		db = new LocationDatabase(this);
	        if(db.getCount() > 0){      	
	        	source = db.getAllLocation();
	        }	
		this.lv = (ListView) this.findViewById(R.id.listView1);
	    this.adapter = new LocationAdapter(source,this);
	    this.lv.setAdapter(adapter); 
	   
	    adapter.notifyDataSetChanged();
	    
	   this.registerForContextMenu(lv);
	    
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub

		int i = item.getItemId();
		switch(i){
		case R.id.delete:
			AlertDialog.Builder ad = new AlertDialog.Builder(this);
			ad.setTitle("Delete Location");
			ad.setMessage("Are you sure you want to delete?");
			ad.setPositiveButton("Yes",this);
			ad.setNegativeButton("No", this);
			
			g = ad.create();
			g.show();
		
			}
		
		return super.onContextItemSelected(item);
	}
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		super.onCreateContextMenu(menu, v, menuInfo);
		getMenuInflater().inflate(R.menu.contextmenu, menu);
		info = (AdapterContextMenuInfo) menuInfo;
		menu.setHeaderTitle("Latitude: "+source.get(info.position).getLat()+"\n"+
							"Longitude: "+source.get(info.position).getLng());
	}
	@Override
	public void onClick(DialogInterface arg0, int arg1) {
		// TODO Auto-generated method stub
		switch(arg1){
		case DialogInterface.BUTTON_POSITIVE:
			String lat = source.get(info.position).getLat();
			db.deleteLocation(lat);
			source.remove(info.position);
			Toast.makeText(this, "Deleted Successfully!", Toast.LENGTH_SHORT).show();
			adapter.notifyDataSetChanged();
			break;
		case DialogInterface.BUTTON_NEGATIVE:
			g.dismiss();
		}
	}

}
